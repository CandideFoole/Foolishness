<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="Paths" tilewidth="64" tileheight="64" tilecount="16" columns="4">
 <image source="../../graphics/environment/Paths.png" width="256" height="256"/>
</tileset>
