<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="House Decoration" tilewidth="64" tileheight="64" tilecount="54" columns="9">
 <image source="../../graphics/environment/House Decoration.png" width="576" height="384"/>
</tileset>
